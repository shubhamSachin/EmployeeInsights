package com.cg.psa.dao;

import java.io.File;
import java.sql.Date;
import java.text.DateFormat;
import java.text.SimpleDateFormat;

import com.cg.psa.exception.UserException;
import com.cg.psa.util.FileUtil;

public class CronJobFileDAO {

	FileUtil util = new FileUtil();
	private String url;
	EmpFileDAO emp = new EmpFileDAO();

	public boolean checkLastModified() throws UserException {
		url = FileUtil.fileUrl();

		File source = new File(url);
		long currentDateTime = source.lastModified();

		Date currentDate = new Date(currentDateTime);

		if (emp.checkFileModification(currentDate)) {
			return true;

		}
		return false;

	}

}
