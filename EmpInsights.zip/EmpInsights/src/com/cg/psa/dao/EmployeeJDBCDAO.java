
package com.cg.psa.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.faces.event.PreDestroyApplicationEvent;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;


import com.cg.psa.bean.EmpTesting;
import com.cg.psa.bean.EmployeePersonal;
import com.cg.psa.bean.Login;
import com.cg.psa.util.JDBCUtil;
@Repository
@Transactional
public class EmployeeJDBCDAO implements IEmployeeJDBCDAO{
    
	@PersistenceContext
	EntityManager em = null;
	public EntityManager getEm() {
		return em;
	}
	public void setEm(EntityManager em) {
		this.em = em;
	}
	
	Login login=new Login();
	EmpTesting et=new EmpTesting();
	
	
	public void storeExcelData()
	{}
	public void validateUser()//validate user
	{}
	public void fetchUsers(String Type,String accountName)//according to type of location and skills
	{}
	public ArrayList<EmpTesting> fetchAllUsers(String accountName )
	{
		String qry="Select emp from EmpTesting emp where emp.sbuName=:accountName";
		TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
 		tq.setParameter("accountName", accountName);
 		ArrayList<EmpTesting> empList=(ArrayList<EmpTesting>) tq.getResultList();
		return empList;
		
	}
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName )
	{
		String qry="Select emp from EmpTesting emp where emp.buName=:accountName";
		TypedQuery<EmpTesting>tq=em.createQuery(qry,EmpTesting.class);
 		tq.setParameter("accountName", accountName);
 		ArrayList<EmpTesting> empList=(ArrayList<EmpTesting>) tq.getResultList();
		return empList;
		
	}
	
	
	
	void updateEmplyee(ArrayList<EmployeePersonal> emp)
	{
		
		
	}
	public void addEmployees()
	{
		
	}
	public Login getLoginDetails(int id) {
       login= em.find(Login.class, id);
		return login;

	}
	
	@Override
	public void updateEmplyee(EmployeePersonal emp) {
	
	}
	@Override
	public EmpTesting getEmployeeDetailsbyId(int id) {
	   et=em.find(EmpTesting.class, id);
		return et;
	}

}
