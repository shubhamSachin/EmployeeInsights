package com.cg.psa.dao;

import java.util.ArrayList;

import com.cg.psa.bean.EmpTesting;
import com.cg.psa.bean.EmployeePersonal;
import com.cg.psa.bean.Login;

public interface IEmployeeJDBCDAO {
	
	void storeExcelData();
	
	void validateUser();//validate user

	void fetchUsers(String Type,String accountName);//according to type of location and skills

	public ArrayList<EmpTesting> fetchAllUsers(String accountName );
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName );

	void updateEmplyee(EmployeePersonal emp);
	
	void addEmployees();
	
	public Login getLoginDetails(int id);
	public EmpTesting getEmployeeDetailsbyId(int id);
	
	
}
