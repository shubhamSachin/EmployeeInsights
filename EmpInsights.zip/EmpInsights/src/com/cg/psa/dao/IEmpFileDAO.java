package com.cg.psa.dao;

public interface IEmpFileDAO {
	void getFiles(String url);
}
