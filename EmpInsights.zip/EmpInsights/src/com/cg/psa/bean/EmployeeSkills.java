package com.cg.psa.bean;

import java.sql.Date;

public class EmployeeSkills {

	 private String empName;
	 private int empId;
	 private String gender;
	 private String designation;
	 private String primarySkills;
	 private String secondarySkills;
	 private String domainSkills;
	 private String achievedCertLevel;
	 private String targetCertLevel;
	 private Date targetMonth;
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getPrimarySkills() {
		return primarySkills;
	}
	public void setPrimarySkills(String primarySkills) {
		this.primarySkills = primarySkills;
	}
	public String getSecondarySkills() {
		return secondarySkills;
	}
	public void setSecondarySkills(String secondarySkills) {
		this.secondarySkills = secondarySkills;
	}
	public String getDomainSkills() {
		return domainSkills;
	}
	public void setDomainSkills(String domainSkills) {
		this.domainSkills = domainSkills;
	}
	public String getAchievedCertLevel() {
		return achievedCertLevel;
	}
	public void setAchievedCertLevel(String achievedCertLevel) {
		this.achievedCertLevel = achievedCertLevel;
	}
	public String getTargetCertLevel() {
		return targetCertLevel;
	}
	public void setTargetCertLevel(String targetCertLevel) {
		this.targetCertLevel = targetCertLevel;
	}
	public Date getTargetMonth() {
		return targetMonth;
	}
	public void setTargetMonth(Date targetMonth) {
		this.targetMonth = targetMonth;
	}
	@Override
	public String toString() {
		return "EmployeeSkills [empName=" + empName + ", empId=" + empId + ", gender=" + gender + ", designation="
				+ designation + ", primarySkills=" + primarySkills + ", secondarySkills=" + secondarySkills
				+ ", domainSkills=" + domainSkills + ", achievedCertLevel=" + achievedCertLevel + ", targetCertLevel="
				+ targetCertLevel + ", targetMonth=" + targetMonth + "]";
	}
	public EmployeeSkills(String empName, int empId, String gender, String designation, String primarySkills,
			String secondarySkills, String domainSkills, String achievedCertLevel, String targetCertLevel,
			Date targetMonth) {
		super();
		this.empName = empName;
		this.empId = empId;
		this.gender = gender;
		this.designation = designation;
		this.primarySkills = primarySkills;
		this.secondarySkills = secondarySkills;
		this.domainSkills = domainSkills;
		this.achievedCertLevel = achievedCertLevel;
		this.targetCertLevel = targetCertLevel;
		this.targetMonth = targetMonth;
	}
	public EmployeeSkills() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 
}
