package com.cg.psa.bean;

public class EmployeePersonal {

	private boolean status;
	private String sbuName;
	private String buName;
	private String accountName;
	private String projectLocation;
	private String engagementMgrName;
	private String engagementMgrMailId;
	
	public boolean isStatus() {
		return status;
	}
	public void setStatus(boolean status) {
		this.status = status;
	}
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getBuName() {
		return buName;
	}
	public void setBuName(String buName) {
		this.buName = buName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getProjectLocation() {
		return projectLocation;
	}
	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}
	public String getEngagementMgrName() {
		return engagementMgrName;
	}
	public void setEngagementMgrName(String engagementMgrName) {
		this.engagementMgrName = engagementMgrName;
	}
	public String getEngagementMgrMailId() {
		return engagementMgrMailId;
	}
	public void setEngagementMgrMailId(String engagementMgrMailId) {
		this.engagementMgrMailId = engagementMgrMailId;
	}
	@Override
	public String toString() {
		return "EmployeePersonal [status=" + status + ", sbuName=" + sbuName + ", buName=" + buName + ", accountName="
				+ accountName + ", projectLocation=" + projectLocation + ", engagementMgrName=" + engagementMgrName
				+ ", engagementMgrMailId=" + engagementMgrMailId + "]";
	}
	public EmployeePersonal() {
		super();
		
	}
	public EmployeePersonal(boolean status, String sbuName, String buName, String accountName, String projectLocation,
			String engagementMgrName, String engagementMgrMailId) {
		super();
		this.status = status;
		this.sbuName = sbuName;
		this.buName = buName;
		this.accountName = accountName;
		this.projectLocation = projectLocation;
		this.engagementMgrName = engagementMgrName;
		this.engagementMgrMailId = engagementMgrMailId;
	}
	
	

}
