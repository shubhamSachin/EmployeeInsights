package com.cg.psa.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="employeeinsights")
public class EmpTesting {
	@Column(name="sbu")
	private String sbuName;
	
	@Column(name="bu")
	private String buName;
	
	@Column(name="account")
	private String accountName;
	
	@Column(name="loc")
	private String projectLocation;
	
	@Id
	@Column(name="id")
	 private int empId;
	
	@Column(name="gender")
	 private String gender;
	
	@Column(name="desig")
	 private String designation;
	
	@Column(name="name")
	 private String name;
	
	@Column(name="manager")
	 private String managerName;
	
	public String getSbuName() {
		return sbuName;
	}
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}
	public String getBuName() {
		return buName;
	}
	public void setBuName(String buName) {
		this.buName = buName;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getProjectLocation() {
		return projectLocation;
	}
	public void setProjectLocation(String projectLocation) {
		this.projectLocation = projectLocation;
	}
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getDesignation() {
		return designation;
	}
	public void setDesignation(String designation) {
		this.designation = designation;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getManagerName() {
		return managerName;
	}
	public void setManagerName(String managerName) {
		this.managerName = managerName;
	}
	public EmpTesting() {
		super();
		// TODO Auto-generated constructor stub
	}
	 
	 
}
