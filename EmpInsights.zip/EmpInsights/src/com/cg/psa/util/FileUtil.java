package com.cg.psa.util;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

import com.cg.psa.exception.UserException;

public class FileUtil {
	

		private static String url;

		static FileInputStream fs = null;

		public static String fileUrl() throws UserException {

			if (url != null) {

				try {

					fs = new FileInputStream("Resource/file.properties");

					Properties prop = new Properties();

					prop.load(fs);

					url = prop.getProperty("url");


					

				} catch (FileNotFoundException e) {
					throw new UserException("File is not found" + e.getMessage());
				} catch (IOException e) {
					// TODO Auto-generated catch block
					throw new UserException("Url is not found" + e.getMessage());
				}
				finally {

					if (fs != null) {

						try {

							fs.close();

						} catch (IOException e) {

							System.err.println(e.getMessage());
							;

						}

					}

				}

			}

			return url;

		}

	}


