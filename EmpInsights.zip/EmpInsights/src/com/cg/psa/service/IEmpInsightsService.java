package com.cg.psa.service;

import java.util.ArrayList;

import com.cg.psa.bean.EmpTesting;
import com.cg.psa.bean.Login;

public interface IEmpInsightsService {
	void validaterUser();
	void fetchUser(String type,String accName);
	public ArrayList<EmpTesting> fetchAllUnit(String unit);
	public ArrayList<EmpTesting> fetchAllUsersBU(String accountName );
	public Login getLoginDetails(int id);
	public EmpTesting getEmployeeDetailsbyId(int id);
}
