package com.cg.psa.service;

import org.springframework.scheduling.annotation.Scheduled;

import com.cg.psa.dao.CronJobFileDAO;
import com.cg.psa.dao.EmpFileDAO;
import com.cg.psa.exception.UserException;

public class CronJob {
	
	
	
	EmpFileDAO emp=new EmpFileDAO();
	CronJobFileDAO cronDao=new CronJobFileDAO();
	
	
		/*
		 * while update we have to check in fts and create one .bak file and that .bak file will be checked with updated and will get list of coloumn name which are updates
		if upadted we will get true from dao method and will update employee detailsS*/
	

	
	 @Scheduled(cron="*/5 * * * * ?")
	public void startCronJob() throws UserException//it will have scheduling code and will call above methods to check for updates
	{
		
		
		if(cronDao.checkLastModified()==true)
		{
			
			
		}
		
	
	}
}
