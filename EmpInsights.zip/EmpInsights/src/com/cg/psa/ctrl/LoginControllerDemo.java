package com.cg.psa.ctrl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

import com.cg.psa.bean.EmpTesting;
import com.cg.psa.bean.Login;
import com.cg.psa.service.IEmpInsightsService;




@Controller
public class LoginControllerDemo {
	//EmpFileJoiner empFileJoiner=new EmpFileJoiner();
	@Autowired
	IEmpInsightsService service = null;
	
	public IEmpInsightsService getService() {
		return service;
	}

	public void setService(IEmpInsightsService service) {
		this.service = service;
	}

//	Login log = new Login();
//	EmpTesting et=new EmpTesting();

//	void displayLogin() throws UserException
//	{
//		empFileJoiner.fileJoiner();
//	}

	@RequestMapping(value="/HomePage")
	public String displayLoginPage(Model model) {
		Login log = new Login();
		EmpTesting et=new EmpTesting();
		model.addAttribute("login", log);
		return"LoginPage";
	}

	@RequestMapping(value="/ValidateUser")
	public String validateUser(@ModelAttribute("login")Login login,Model model)
	{
		Login log = new Login();
		EmpTesting et=new EmpTesting();
		log=service.getLoginDetails(login.getEmpId());
		et=service.getEmployeeDetailsbyId(login.getEmpId());
		
		if(log==null) {
			model.addAttribute("errorMsg", "Account does not exist");
			return "LoginPage";
		}else if(log.getPassword().equals(login.getPassword())) {
			 if(et.getDesignation().equalsIgnoreCase("Manager")) {
					return "ManagerPage";
			 }else if(et.getDesignation().equalsIgnoreCase("BUHead")) {
				 return "BUHeadPage";
			 }else {
				 return "Test";
			 }
			}else
		return "Test";
		
	}
	
	@RequestMapping(value="/sbu")
	public String EmpInfoBySBU(Model model) {
		Login log = new Login();
		EmpTesting empTest= new EmpTesting();
		model.addAttribute("et1",empTest);
		ArrayList<String> cityList= new ArrayList<String>();
	      cityList.add("Apps2Euorpe");
	      cityList.add("Apps2Africa");
	      model.addAttribute("sbulist", cityList);
	      
		return "ChooseSBU";	
	}
	@RequestMapping(value="/sbuListFinal")
	public String EmpInfoBySBUFinal(@ModelAttribute("et1")EmpTesting empTest,Model model) {
		ArrayList<EmpTesting> List=service.fetchAllUnit(empTest.getSbuName());
		model.addAttribute("List", List);
		return "SBUResult";	
	}

	@RequestMapping(value="/bu")
	public String EmpInfoByBU(Model model) {
		Login log = new Login();
		EmpTesting empTest= new EmpTesting();
		model.addAttribute("et1",empTest);
		ArrayList<String> cityLis= new ArrayList<String>();
	      cityLis.add("BU1");
	      cityLis.add("BU2");
	      model.addAttribute("bulist", cityLis);
	      
		return "ChooseBU";	
	}
	@RequestMapping(value="/buListFinal")
	public String EmpInfoByBUFinal(@ModelAttribute("et1")EmpTesting empTest,Model model) {
		ArrayList<EmpTesting> List=service.fetchAllUsersBU(empTest.getBuName());
		model.addAttribute("List",List);
		return "SBUResult";	
	}



}
